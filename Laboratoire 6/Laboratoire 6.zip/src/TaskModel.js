/**
 * Created by SimonG on 2/10/2015.
 */

var Task = Backbone.Model.extend({
    defaults : function(){
        return{
            task : 'Empty task'
        };
    }
});