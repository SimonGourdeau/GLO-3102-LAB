How to use our awesome calculator:

var cal = Calculator();
cal.add(2).add(3).equals(); // outputs 5
cal.equals() // still output 5
cal.clear().equals() // outputs 0
cal.factorial(-3).equals() // throws error